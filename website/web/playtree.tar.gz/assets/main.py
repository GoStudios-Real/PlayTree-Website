#!/usr/bin/env python3
"""
PLAYTREE — Chapter 0 : Season 0
A stylized multiplayer fantasy adventure game.
"""

import pygame
import sys
import os

if getattr(sys, 'frozen', False):
    _base = sys._MEIPASS
    os.chdir(os.path.dirname(sys.executable))
else:
    _base = os.path.dirname(os.path.abspath(__file__))

sys.path.insert(0, _base)

from config import WIDTH, HEIGHT, TITLE, FPS, BLACK
from src.game import Game
from src.loading_screen import LoadingScreen

def is_mobile():
    if sys.platform in ("android", "ios"):
        return True
    if hasattr(sys, "getandroidapilevel"):
        return True
    return False

def main():
    if is_mobile():
        os.environ['SDL_AUDIODRIVER'] = 'dummy'
    pygame.init()
    pygame.font.init()
    try:
        pygame.joystick.init()
    except Exception:
        pass

    saved_settings = None
    try:
        from src.save_system import load_settings
        saved_settings = load_settings()
    except Exception:
        pass

    is_fullscreen = True
    if saved_settings and "fullscreen" in saved_settings:
        is_fullscreen = saved_settings["fullscreen"]

    if is_mobile():
        try:
            info = pygame.display.Info()
            monitor_w, monitor_h = info.current_w, info.current_h
        except Exception:
            monitor_w, monitor_h = WIDTH, HEIGHT
        try:
            display = pygame.display.set_mode((monitor_w, monitor_h), pygame.FULLSCREEN)
        except Exception:
            try:
                display = pygame.display.set_mode((0, 0))
            except Exception:
                display = pygame.display.set_mode((WIDTH, HEIGHT))
    elif is_fullscreen:
        try:
            info = pygame.display.Info()
            monitor_w, monitor_h = info.current_w, info.current_h
        except Exception:
            monitor_w, monitor_h = 1920, 1080
        flags = pygame.FULLSCREEN | pygame.DOUBLEBUF
        try:
            display = pygame.display.set_mode((monitor_w, monitor_h), flags)
        except Exception:
            display = pygame.display.set_mode((WIDTH, HEIGHT))
    else:
        flags = pygame.DOUBLEBUF
        display = pygame.display.set_mode((WIDTH, HEIGHT), flags)

    pygame.display.set_caption(TITLE)
    pygame.mouse.set_visible(not is_mobile())

    render_surface = pygame.Surface((WIDTH, HEIGHT))

    try:
        icon = pygame.Surface((32, 32))
        icon.fill((10, 30, 15))
        pygame.draw.circle(icon, (80, 180, 60), (16, 16), 12)
        pygame.draw.circle(icon, (100, 255, 120), (16, 12), 8)
        pygame.display.set_icon(icon)
    except:
        pass

    clock = pygame.time.Clock()
    game = Game(render_surface)
    loading = LoadingScreen(render_surface)
    started = False
    running = True

    # --- Loading screen loop: progress then wait for PLAY ---
    while running and not started:
        dt = clock.tick(FPS) / 1000.0
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if loading.handle_event(event):
                if loading.ready:
                    started = True
        loading.update(dt)
        loading.draw()
        dw, dh = display.get_size()
        scaled = pygame.transform.smoothscale(render_surface, (dw, dh)) if (dw, dh) != (WIDTH, HEIGHT) else render_surface
        display.blit(scaled, (0, 0))
        pygame.display.flip()

    while running:
        dt = clock.tick(FPS) / 1000.0
        dt = min(dt, 0.05)

        events = pygame.event.get()
        for event in events:
            if event.type == pygame.QUIT:
                running = False
            if not is_mobile() and event.type == pygame.KEYDOWN and event.key == pygame.K_F11:
                is_fullscreen = not is_fullscreen
                try:
                    info = pygame.display.Info()
                    monitor_w, monitor_h = info.current_w, info.current_h
                except Exception:
                    monitor_w, monitor_h = 1920, 1080
                if is_fullscreen:
                    flags = pygame.FULLSCREEN | pygame.DOUBLEBUF
                    try:
                        display = pygame.display.set_mode((monitor_w, monitor_h), flags)
                    except Exception:
                        display = pygame.display.set_mode((WIDTH, HEIGHT))
                else:
                    flags = pygame.DOUBLEBUF
                    display = pygame.display.set_mode((WIDTH, HEIGHT), flags)

        try:
            game.handle_events(events)
            game.update(dt)
            game.draw()
        except Exception as e:
            import traceback
            traceback.print_exc()

        dw, dh = display.get_size()
        if dw <= 0 or dh <= 0:
            dw, dh = WIDTH, HEIGHT
        if dw != WIDTH or dh != HEIGHT:
            scaled = pygame.transform.smoothscale(render_surface, (dw, dh))
            display.blit(scaled, (0, 0))
        else:
            display.blit(render_surface, (0, 0))
        pygame.display.flip()

        if not game.running:
            running = False

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
